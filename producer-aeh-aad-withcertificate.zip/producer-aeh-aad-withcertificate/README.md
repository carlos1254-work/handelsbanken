# MSAL Java sample demonstrating how a daemon console application, using Kafka Producer API, can send events to Azure Event Hubs using its own identity

## About this sample

### Overview

This app demonstrates how to use the [Microsoft identity platform](http://aka.ms/aadv2) to send events to Azure Event Hubs in a long-running, non-interactive process. It uses the [Microsoft Authentication Library (MSAL) for Java](https://github.com/AzureAD/microsoft-authentication-library-for-java) to acquire an [access token](https://docs.microsoft.com/azure/active-directory/develop/access-tokens), which it then is used to send the events to [Azure Event Hubs](https://learn.microsoft.com/en-us/azure/event-hubs/). The sample utilizes the [OAuth 2 client credentials grant](https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-oauth2-client-creds-grant-flow) and a private key/certificate pair to obtain an access token for calls to Azure Event Hubs.

## Scenario

The console application:

- Acquires an access token from Azure AD using its own identity (without a user).
- It then sends events to Azure Event Hubs using Kafka Producer API.

![Topology](topology.png)

For more information on the concepts used in this sample, be sure to read the [Microsoft identity platform endpoint client credentials protocol documentation](https://azure.microsoft.com/documentation/articles/active-directory-v2-protocols-oauth-client-creds).

## How to run this sample

To run this sample, you'll need:

- Working installation of [Java 8 or greater](https://openjdk.java.net/install/) and [Maven](https://maven.apache.org/).
- An Azure Active Directory (Azure AD) tenant. For more information on how to get an Azure AD tenant, see [How to get an Azure AD tenant](https://azure.microsoft.com/en-us/documentation/articles/active-directory-howto-tenant/).
- One or more user accounts in your Azure AD tenant.

### Step 1:  Clone or download this repository

From your shell or command line:

```Shell
git tbd
```

or download and extract the repository .zip file.

### Step 2:  Register the sample with your Azure Active Directory tenant

To register the project, you can:

- either follow the steps [Step 2: Register the sample with your Azure Active Directory tenant](#step-2-register-the-sample-with-your-azure-active-directory-tenant) and [Step 3: Configure the sample to use your Azure AD tenant](#choose-the-azure-ad-tenant-where-you-want-to-create-your-applications)
- or use PowerShell scripts that:
  - **automatically** creates the Azure AD applications and related objects (passwords, permissions, dependencies) for you.
  - modify the project's configuration files.

Follow the steps below to manually walk through the steps to register and configure the applications.

#### Choose the Azure AD tenant where you want to create your applications

As a first step you'll need to:

1. Sign in to the [Azure portal](https://portal.azure.com) using either a work or school account or a personal Microsoft account.
1. If your account is present in more than one Azure AD tenant, select your profile at the top right corner in the menu on top of the page, and then **switch directory**.
   Change your portal session to the desired Azure AD tenant.
1. In the portal menu, select the **Azure Active Directory** service, and then select **App registrations**.

#### Register the client app (java-daemon-console)

1. Navigate to the Microsoft identity platform for developers [App registrations](https://go.microsoft.com/fwlink/?linkid=2083908) page.
1. Select **New registration**.
   - In the **Name** section, enter a meaningful application name that will be displayed to users of the app, for example `java-daemon-console`.
   - In the **Supported account types** section, select **Accounts in this organizational directory only ({tenant name})**.
   - Click **Register** button at the bottom to create the application.
1. On the application **Overview** page, find the **Application (client) ID** and **Directory (tenant) ID** values and record it for later. You'll need it to configure the configuration file(s) later in your code.
1. Go to the Azure Event Hubs namespace that contains the Event Hub that you will use to send the events. In the left menu, click on the **Access Control (IAM)** to open the page where we add access to the Role that your application needs.
   - Click the **Add role assignment** button and then,
   - Select **Azure Event Hubs Data Sender** option, click the **Next** button and then,
   - Ensure that **User, group or service principal** is selected and click on **Select members**,
   - In the **Select Members** section, type your **application name** then click on **Select**,
   - Ensure that the **application name** is displayed in the windows and then click on **Next**,
   - Click on **Review + assign**

   
#### Create a private key and certificate

This sample requires a private key in PKCS8 format and a certificate in X509 format. 

There are many ways to generate keys and certificates. As one example, below are terminal commands to generate the key and cert using OpenSSL:

Generate the private key in PEM format (used to make the certificate) and create a PKCS8 version (use by the sample application)
 - `openssl genrsa -out private_key.pem 2048`
 - `openssl pkcs8 -topk8 -inform PEM -outform DER -in private_key.pem  -nocrypt > pkcs8_key`
 
Generate a certificate using the private key.
 - `openssl req -new -key private_key.pem -out cert.csr`
   - This first command will ask for a variety of extra information, like company name, country, and a password. None of this is used by the sample, so you can set these values as nothing/anything you want
 - `openssl x509 -req -days 365 -in cert.csr -signkey private_key.pem -out cert.crt`

Finally, go back to the Azure portalIn the Application menu blade, click on the **Certificates & secrets**, in the **Certificates** section, upload the certificate you created.

### Step 3:  Configure the client app (java-daemon-console) to use your app registration

Open the project in your IDE to configure the code.
>In the steps below, "azAppId" is the same as "Application ID" or "AppId" and "azTenantId" is same as "Directory ID".

1. Open the `producer-aeh-aad-withcertificate\src\main\resources\application.properties` class
2. Set the `topic` property to the topic name in the Azure Event Hubs namespace
3. Set the `azAppId` property to the application/client ID value you recorded earlier
4. Set the `azTenantId` property to the directory/tenant ID value you recorded earlier 
5. Set the `keyPath` property to the path to the private key you generated earlier (by default, the application reads the private key from the Resources folder)
6. Set the `certPath` property to the path to the certificate you generated earlier (by defualt, the application reads the certificate from the Resources folder)

### Step 4: Run the sample

You can test the sample directly by running the main method of App.java from your IDE.

From your shell or command line:

- `$ mvn clean compile`
- `$ mvn package`

This will generate a `producer-aeh-aad-withappsecret-1.0.jar` file in your /targets directory. Run this using your Java executable like below:

- `$ java -jar producer-aeh-aad-withappsecret-1.0.jar`


After running, the application should display the list of user in the configured tenant.

## About the code

The relevant code for this sample is in the `CertificateAuthenticationCallbackHandler.java` file.

1. Load the private key and certificate

   ```Java
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(Files.readAllBytes(Paths.get(this.keyPath)));
        PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(spec);

        InputStream certStream = new ByteArrayInputStream(Files.readAllBytes(Paths.get(this.certPath)));
        X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(certStream);

   ```

2. Create the MSAL confidential client application.

   Important note: even if we are building a console application, it is a daemon, and therefore a confidential client application, as it does not
   access Web APIs on behalf of a user, but on its own application behalf.

    ```Java
        IClientCredential credential = ClientCredentialFactory.createFromCertificate(key, cert);
        this.aadClient = ConfidentialClientApplication.builder(this.azAppId, credential)
                .authority(this.azAuthority)
                .build();
    ```
3. Acquire the bearer token, create the CustomAuthBearerToken with the token id and the expiration date

   ```Java
        IAuthenticationResult authResult = this.aadClient.acquireToken(this.aadParameters).get();
        return new CustomOAuthBearerToken(authResult.accessToken(), authResult.expiresOnDate());
   ```