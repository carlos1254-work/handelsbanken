package carlosmed.messaging.kafka;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.time.Duration;
import java.time.Instant;
import java.util.Properties;

public class App 
{
    private static final Logger logger = LogManager.getLogger("producer-aeh-aad-withappsecret");

    public static void main( String[] args ) {

        Instant start = Instant.now();
        logger.info("Starting...");
        try {
            // load app properties
            PropertiesHelper.loadProperties();;

            // load the topic name
            String topic = PropertiesHelper.getAppProperties().getProperty("topic");

            // create kafka-producer
            Producer<String, String> producer = new KafkaProducer<String, String>(PropertiesHelper.getKafkaProperties());
            try {
                // create kafka-record
                ProducerRecord<String, String> record = new ProducerRecord<>(topic, "hello");
                // send the record
                producer.send(record);
                logger.info(String.format("message sent... %s", 0));

            } finally {
                // flush and close kafka-producer
                producer.flush();
                producer.close();
            }
        } catch(Exception e) {
            logger.error("Error... ", e);
        } finally {
            logger.info(String.format("Ending... duration: %s", Duration.between(start, Instant.now())));
        }

    }
}
