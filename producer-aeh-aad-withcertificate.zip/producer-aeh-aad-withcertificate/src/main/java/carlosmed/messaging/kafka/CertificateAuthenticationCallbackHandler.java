package carlosmed.messaging.kafka;

import com.microsoft.aad.msal4j.*;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.security.auth.AuthenticateCallbackHandler;
import org.apache.kafka.common.security.oauthbearer.OAuthBearerToken;
import org.apache.kafka.common.security.oauthbearer.OAuthBearerTokenCallback;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.UnsupportedCallbackException;
import javax.security.auth.login.AppConfigurationEntry;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutionException;

public class CertificateAuthenticationCallbackHandler implements AuthenticateCallbackHandler {

    private volatile ConfidentialClientApplication aadClient;
    private ClientCredentialParameters aadParameters;
    private String azAuthority;
    private String azAppId;
    private String keyPath;
    private String certPath;

    @Override
    public void configure(Map<String, ?> map, String s, List<AppConfigurationEntry> list) {
        // todo: document what I am going to do here
        String bootstrapServer = Collections.singletonList(map.get(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG)).get(0).toString();
        bootstrapServer = bootstrapServer.replaceAll("\\[|\\]", "");
        URI uri = URI.create("https://" + bootstrapServer);
        String sbUri = uri.getScheme() + "://" + uri.getHost();
        this.aadParameters = ClientCredentialParameters
                .builder(Collections.singleton(sbUri + "/.default"))
                .build();

        try {
            Properties appProperties = PropertiesHelper.getAppProperties();
            this.azAuthority = String.format("https://login.microsoftonline.com/%s", appProperties.getProperty("azTenantId"));
            this.azAppId = appProperties.getProperty("azAppId");
            this.keyPath = String.format("src/main/resources/%s", appProperties.getProperty("keyPath"));
            this.certPath = String.format("src/main/resources/%s", appProperties.getProperty("certPath"));
        } catch (Exception e) {
        }
    }

    @Override
    public void close() {

    }

    @Override
    public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
        for (Callback callback: callbacks) {
            if (callback instanceof OAuthBearerTokenCallback) {
                try {
                    OAuthBearerToken token = getOAuthBearerToken();
                    OAuthBearerTokenCallback oauthCallback = (OAuthBearerTokenCallback) callback;
                    oauthCallback.token(token);
                } catch (MalformedURLException | ExecutionException | InterruptedException | NoSuchAlgorithmException |
                         InvalidKeySpecException | CertificateException e) {
                    e.printStackTrace();
                }
            } else {
                throw new UnsupportedCallbackException(callback);
            }
        }
    }

    private OAuthBearerToken getOAuthBearerToken() throws IOException, ExecutionException, InterruptedException, NoSuchAlgorithmException, InvalidKeySpecException, CertificateException {
        if (this.aadClient == null) {
            synchronized (this) {
                if (this.aadClient == null) {

                    PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(Files.readAllBytes(Paths.get(this.keyPath)));
                    PrivateKey key = KeyFactory.getInstance("RSA").generatePrivate(spec);

                    InputStream certStream = new ByteArrayInputStream(Files.readAllBytes(Paths.get(this.certPath)));
                    X509Certificate cert = (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(certStream);

                    IClientCredential credential = ClientCredentialFactory.createFromCertificate(key, cert);
                    this.aadClient = ConfidentialClientApplication.builder(this.azAppId, credential)
                            .authority(this.azAuthority)
                            .build();
                }
            }
        }

        IAuthenticationResult authResult = this.aadClient.acquireToken(this.aadParameters).get();
        return new CustomOAuthBearerToken(authResult.accessToken(), authResult.expiresOnDate());
    }
}
