package carlosmed.messaging.kafka;

import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class PropertiesHelper {

    private static Map<String, Properties> properties = new HashMap<>();
    public static final String appProperties = "app.properties";

    public static final String kafkaProperties = "kafka-server.properties";

    public static void loadProperties() throws IOException {
        String[] fileNames = new String[]{appProperties, kafkaProperties};
        for (String fileName: fileNames) {
            Properties props = new Properties();
            String filePath = String.format("src/main/resources/%s", fileName);
            props.load(new FileReader(filePath));
            properties.put(fileName, props);
        }
    }

    public static Properties getAppProperties() {
        return properties.get(appProperties);
    }

    public static String getAppProperty(String property) {
        return getAppProperties().getProperty(property);
    }

    public static Properties getKafkaProperties() {
        return properties.get(kafkaProperties);
    }

    public static String getKafkaProperty(String property) {
        return getKafkaProperties().getProperty(property);
    }

}
